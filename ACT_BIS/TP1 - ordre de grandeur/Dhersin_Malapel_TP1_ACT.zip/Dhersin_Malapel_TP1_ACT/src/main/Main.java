package main;

import graphic.Fenetre;

public class Main {

	static Fenetre fenetre;
	
	public static void main(String[] args) {
		fenetre = new Fenetre();
	}
}