package classesPb;


public abstract class ExpTime extends PbDecision {
	public abstract boolean aUneSolution();
	//doit etre de complexite temporelle au plus exponentielle
}