package classesPb;

public abstract class PbDecision {
	
	public abstract boolean aUneSolution();
	
}