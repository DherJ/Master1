/*************************************************/
/****  Dhersin J�r�me - Malapel Florian  *********/
/****          TP ACT - Classe NP        *********/
/****               24/11/2015           *********/
/*************************************************/


Toutes les impl�mentations fonctionnent

Hamilton Cycle -> TSP  => OK
Hamilton Path -> Hamilton Cycle => OK
Hamilton Path -> Hamilton Cycle -> TSP  => OK
Enum�ration de tous les certificats  => OK